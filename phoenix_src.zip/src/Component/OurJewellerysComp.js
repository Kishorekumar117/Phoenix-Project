import React, { Component } from 'react'

import { Button } from 'react-bootstrap';

import wall_c from '../Shared/Images/wallpaperflare.com_wallpaper.jpg'
import wall_d from '../Shared/Images/wallpaperflare.com_wallpaper (2).jpg'
import wall_e from '../Shared/Images/wallpaperflare.com_wallpaper (1).jpg'

import Card from 'react-bootstrap/Card';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';


import line from '../Shared/Images/line.png';


export class OurJewellerysComp extends Component {


    render() {
        
        const len=4;
        return (

            <div>
                <br></br><br></br><br></br><br></br>
    























            {/* ================================================================ */}
                 <h3 class="stip">  <img src={line} style={{width:"140px",height:"80px"}} />{" "}JEWELLERY{" "}  
  <img src={line} style={{width:"140px",height:"80px"}}/></h3>
  
    {/* <div class="container mt-2 ">
    <div class="row">
    <div class="col-md-4 ">
    
  <div class="shows">
  <img src={wall_c} alt="Notebook"/>
  <div class="content">
    <h1 style={{textAlign:'left'}}>Heading</h1>
    <p style={{textAlign:'left'}}>Lorem ipsum dolor sit amet, an his etiam torquatos. Tollit soleat phaedrum te duo, eum cu recteque expetendis neglegentur. Cu mentitum maiestatis persequeris pro, pri ponderum tractatos ei.</p>
  </div>
</div>





      
      </div>
    <div class="col-md-4"> 

  <div class="shows">
  <img src={wall_d} alt="Notebook"/>
  <div class="content">
    <h1 style={{textAlign:'left'}}>Heading</h1>
    <p style={{textAlign:'left'}}>Lorem ipsum dolor sit amet, an his etiam torquatos. Tollit soleat phaedrum te duo, eum cu recteque expetendis neglegentur. Cu mentitum maiestatis persequeris pro, pri ponderum tractatos ei.</p>
  </div>
</div>
  
    
    </div>
    <div class="col-md-4"> 

    <div class="shows">
    <img src={wall_e} alt="Notebook"/>
    <div class="content">
      <h1 style={{textAlign:'left'}}>Heading</h1>
      <p style={{textAlign:'left'}}>Lorem ipsum dolor sit amet, an his etiam torquatos. Tollit soleat phaedrum te duo, eum cu recteque expetendis neglegentur. Cu mentitum maiestatis persequeris pro, pri ponderum tractatos ei.</p>
    </div>
    </div>

    </div>

 </div>

 </div> */}
            </div>
        )
    }
}

export default OurJewellerysComp
